namespace newProject.Models
{
    public class Emp_Master
    {
        public int Emp_Id {get;set;}
        public string Emp_Name {get;set;} = string.Empty;
    }
}