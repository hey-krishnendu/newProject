namespace newProject.Models
{
    public class Salary_Master
    {
        public int Salary_id {get;set;}
        public decimal Amount {get;set;}
        public DateTime DisburshedDate {get;set;}
        public int Emp_ID {get;set;}
    }
}