namespace newProject.Models
{
    public class EmployeeViewModel
    {
        public IEnumerable<Emp_Master> AllEmaps {get; set;} = Enumerable.Empty<Emp_Master>();
    }
}